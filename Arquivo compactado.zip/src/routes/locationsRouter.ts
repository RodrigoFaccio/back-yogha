import express from 'express';
import {
  getLocationsController,
  getLocationAutocompleteController,
  getLocationLiveController
} from '../controllers/locations';

const router = express.Router();

router.get('/', getLocationsController);
router.get('/searchAddressAutocomplete', getLocationAutocompleteController);
router.get('/reservation', getLocationLiveController);

export default router;
